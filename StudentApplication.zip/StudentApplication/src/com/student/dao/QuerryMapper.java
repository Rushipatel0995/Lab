package com.student.dao;

public interface QuerryMapper {
	
	public static final String viewAll="select studentroll,studentname,dob from student_tbl";

}
