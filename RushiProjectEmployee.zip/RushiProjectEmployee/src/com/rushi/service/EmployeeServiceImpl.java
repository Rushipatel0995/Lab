package com.rushi.service;

import java.util.List;

import com.rushi.bean.EmployeeBean;
import com.rushi.dao.EmployeeDaoImpl;
import com.rushi.dao.IEmployeeDao;
import com.rushi.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	private IEmployeeDao employeeDao = new EmployeeDaoImpl();
	@Override
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		return employeeDao.insertEmployee(employeeBean);
	}

	@Override
	public EmployeeBean searchEmployee(int empid) throws EmployeeException {
		return employeeDao.searchEmployee(empid);
	}

	@Override
	public List<EmployeeBean> getAllEmployee() throws EmployeeException {
		return employeeDao.getAllEmployee();
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException {
		return employeeDao.deleteEmployee(empid);
	}

	@Override
	public boolean updateSal(int empid, double salary) throws EmployeeException {
		IEmployeeDao empDAO = new EmployeeDaoImpl();

		boolean isUpdated = empDAO.updateSal(empid,salary);
		return isUpdated;
	}

}
