package com.rushi.service;

import java.util.List;

import com.rushi.bean.EmployeeBean;
import com.rushi.exception.EmployeeException;

public interface IEmployeeService {
public boolean insertEmployee(EmployeeBean employeeBean)throws EmployeeException;
	
	public EmployeeBean searchEmployee(int empid)throws EmployeeException;
	
	public List<EmployeeBean> getAllEmployee()throws EmployeeException;
	
	public boolean deleteEmployee(int empid)throws EmployeeException;
	
	public boolean updateSal(final int empid,final double d)
			throws EmployeeException;
}
