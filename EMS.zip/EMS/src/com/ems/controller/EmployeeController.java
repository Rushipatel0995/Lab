package com.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping("showHomePage")
	public String showHomePage(){
		return "index";
	}
	
	@RequestMapping(value="addEmployee",method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("emp") EmployeeBean bean,BindingResult result){
		
		
		ModelAndView model=new ModelAndView();
		if(result.hasErrors()){
		
			model.setViewName("error");
			model.addObject("message","Binding Failed");
		
		}
		else{
			
			try {
				int id=employeeService.addEmployee(bean);
				model.setViewName("success");
				model.addObject("id",id);
				model.addObject("emp",bean);
			} catch (EmployeeException e) {
				model.setViewName("error");
				model.addObject("message",e.getMessage());
			}
			
		}
		
		return model;
	}
	
	@RequestMapping("showAll")
	public ModelAndView viewAll(@ModelAttribute("emp") EmployeeBean bean){
		
		ModelAndView model=new ModelAndView();
		
		
		try {
			List<EmployeeBean> list=employeeService.viewAll();
			
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());
		}
		
		
		return model;
		
	}
	
	@RequestMapping("deleteEmployee")
	public ModelAndView deleteEmployee(@RequestParam("id") int id){
		ModelAndView model = new ModelAndView();
		
		try {
			boolean isDeleted=employeeService.deleteEmployee(id);
			
			
			model.addObject("delete",isDeleted);
			List<EmployeeBean> list=employeeService.viewAll();
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message", "Unable to delete employee"+e.getMessage());
		}
		
		return model;
		
	}
	
	@RequestMapping("updateEmployee")
	public ModelAndView updateEmployee(@ModelAttribute("emp") EmployeeBean bean){
		ModelAndView model=new ModelAndView();
		model.setViewName("update");
		model.addObject("emp",bean);
		return model;
	}
	
	@RequestMapping("updatesuc")
	public ModelAndView updateEmp(@ModelAttribute("emp") EmployeeBean bean){
		ModelAndView model=new ModelAndView();
		try {
			boolean isUpdated=employeeService.updateEmployee(bean);
			
			model.addObject("update",isUpdated);
			List<EmployeeBean> list=employeeService.viewAll();
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message","Unable to update employee in controller");
		}
		
		return model;
	}
	
}
