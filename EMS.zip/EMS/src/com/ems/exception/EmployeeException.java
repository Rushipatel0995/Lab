package com.ems.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9008217029443296454L;
	
	public EmployeeException(){
		super();
	}
	public EmployeeException(String message){
		super(message);
	}
	

}
