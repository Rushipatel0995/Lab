package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getEmployeeId();
		} catch (Exception e) {
			throw new EmployeeException("Unable to persist in dao layer"+e.getMessage());
			
		}
		
		return id;
	}
	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException {
		
		List<EmployeeBean> list=null;
		try {
			TypedQuery<EmployeeBean> qry = entityManager.createQuery("from EmployeeBean",EmployeeBean.class);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("unable to fetch data in dao layer!"+e.getMessage());
		}
		
		return list;
	}
	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		boolean isDeleted=false;
		
		try {
			EmployeeBean emp=entityManager.find(EmployeeBean.class,id);
			


				entityManager.remove(emp);
				isDeleted=true;
		} catch (Exception e) {
			throw new EmployeeException("Unable to delete in dao layer!"+e.getMessage());
			
		}
			
		
		
		return isDeleted;
	}
	@Override
	public boolean updateEmployee(EmployeeBean bean) throws EmployeeException {
		boolean isUpdated=false;
		
		
		try {
		//	EmployeeBean emp=entityManager.find(EmployeeBean.class, bean.getEmployeeId());

			
				//emp.setEmployeeName("Shyam");
				
				entityManager.merge(bean);
				isUpdated=true;
		} catch (Exception e) {
			throw new EmployeeException("Unable to update employee in dao layer"+e.getMessage());
		}
		
		return isUpdated;
	}

}
