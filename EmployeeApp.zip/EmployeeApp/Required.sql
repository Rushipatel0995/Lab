CREATE TABLE EMPLOY12 (empid number, empname varchar2(30), empDob date, salary number(5,2), designation varchar2(20));

CREATE SEQUENCE play_seq START WITH 1010;