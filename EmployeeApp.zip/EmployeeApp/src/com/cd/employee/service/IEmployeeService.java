package com.cd.employee.service;

import java.util.List;

import com.cd.employee.bean.EmployeeBean;
import com.cd.employee.exception.EmployeeException;

public interface IEmployeeService {
public boolean insertEmployee(EmployeeBean employeeBean)throws EmployeeException;
	
	public EmployeeBean getEmployee(int empid)throws EmployeeException;
	
	public List<EmployeeBean> getAllEmployee()throws EmployeeException;
	
	public boolean deleteEmployee(int empid)throws EmployeeException;

}
