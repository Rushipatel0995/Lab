package com.cd.employee.bean;

import java.time.LocalDate;

public class EmployeeBean {
	private int empId;
	private String empName;
	private LocalDate empDob;
	private double salary;
	private String designation;
	
	public EmployeeBean() {
		super();
	}

	public EmployeeBean( String empName, LocalDate empDob,
			double salary, String designation) {
		super();
		
		this.empName = empName;
		this.empDob = empDob;
		this.salary = salary;
		this.designation = designation;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public LocalDate getEmpDob() {
		return empDob;
	}

	public void setEmpDob(LocalDate empDob) {
		this.empDob = empDob;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empName=" + empName
				+ ", empDob=" + empDob + ", salary=" + salary
				+ ", designation=" + designation + "]";
	}
	
	

}
