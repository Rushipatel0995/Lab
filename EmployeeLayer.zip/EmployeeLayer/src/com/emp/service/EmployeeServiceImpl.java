package com.emp.service;

import com.emp.bean.Employee;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.dao.IEmployeeDao;

public class EmployeeServiceImpl implements IEmployeeService {
	
	
	IEmployeeDao employeeDao = new EmployeeDaoImpl();
	
	public IEmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(IEmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Override
	public Employee viewAll(int id) {
		Employee employee=employeeDao.viewAll(id);
		return employee;
	}

}
