package com.emp.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.emp.bean.Employee;
import com.emp.service.EmployeeServiceImpl;
import com.emp.service.IEmployeeService;

public class TestApp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		IEmployeeService obj1=(EmployeeServiceImpl)ctx.getBean("employeeServiceImpl");
		//Employee obj = (Employee)ctx.getBean("employee");
		
		
		Employee emp=obj1.viewAll(2);
		
		System.out.println(emp);
		
	
	}

}
