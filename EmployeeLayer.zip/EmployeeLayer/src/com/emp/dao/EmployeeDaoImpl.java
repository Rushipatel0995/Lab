package com.emp.dao;

import java.util.HashMap;

import com.emp.bean.Employee;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	private HashMap<Integer,Employee> empList;
	
	
	public HashMap<Integer, Employee> getEmpList() {
		return empList;
	}


	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empList = empList;
	}


	@Override
	public Employee viewAll(int id) {
		Employee employee= empList.get(id);
		return employee;
	}

}
