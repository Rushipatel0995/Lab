package com.product.service;

import java.util.List;

import com.product.bean.Product;
import com.product.exception.ProductException;

public interface IProductService {
	public List<Product> viewAll() throws ProductException;
	
	public boolean delete(int product_id) throws ProductException;
}
