package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.product.bean.Product;
import com.product.exception.ProductException;
import com.product.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;
	
	@RequestMapping("showHomePage")
	public ModelAndView showHome(@ModelAttribute("product") Product product){
		ModelAndView model=new ModelAndView();
		
		try {
			List<Product> list=productService.viewAll();
			model.addObject("list",list);
			model.setViewName("index");
			
		} catch (ProductException e) {
			model.setViewName("error");
			model.addObject("message","unable to retrieve");
		}
		
		return model;
	}
	
	@RequestMapping("delete")
	public ModelAndView delete(@RequestParam("product_id") int product_id){
ModelAndView model = new ModelAndView();
		
		try {
			boolean isDeleted=productService.delete(product_id);
			
			
			model.addObject("delete",isDeleted);
			List<Product> list=productService.viewAll();
			model.setViewName("index");
			model.addObject("list",list);
		} catch (ProductException e) {
			model.setViewName("error");
			model.addObject("message", "Unable to delete employee"+e.getMessage());
		}
		
		return model;
	}
	
}
