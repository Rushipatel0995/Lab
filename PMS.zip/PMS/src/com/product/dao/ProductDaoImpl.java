package com.product.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.product.bean.Product;
import com.product.exception.ProductException;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Product> viewAll() throws ProductException {
		List<Product> list=null;
		try {
			TypedQuery<Product> qry = entityManager.createQuery("from Product",Product.class);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new ProductException("unable to fetch data in dao layer!"+e.getMessage());
		}
		
		return list;
	}

	@Override
	public boolean delete(int product_id) throws ProductException {
boolean isDeleted=false;
		
		try {
			Product product=entityManager.find(Product.class,product_id);
			


				entityManager.remove(product);
				isDeleted=true;
		} catch (Exception e) {
			throw new ProductException("Unable to delete in dao layer!"+e.getMessage());
			
		}
			
		
		
		return isDeleted;
	}

}
