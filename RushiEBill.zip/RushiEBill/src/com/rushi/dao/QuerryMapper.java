package com.rushi.dao;

public interface QuerryMapper {
	public static final String viewAll="select * from Consumers";
	public static String INSERTQUERY="INSERT INTO Consumers VALUES(?,?,?)";
	public static String DELETEQUERY="delete from Consumers where consumer_num=? ";
}