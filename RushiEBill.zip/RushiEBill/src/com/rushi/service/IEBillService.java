package com.rushi.service;

import java.util.List;

import com.rushi.bean.EBillBean;
import com.rushi.exception.BillException;

public interface IEBillService {
	List<EBillBean> viewAllStudentDetails() throws BillException;
	
	public boolean insertBill(EBillBean bill) throws BillException;
	
	public boolean deleteBill(int consumerNum) throws BillException;
	
	public EBillBean search(final int consumerNum)
			throws BillException;
}
