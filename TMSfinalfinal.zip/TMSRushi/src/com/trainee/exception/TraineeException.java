package com.trainee.exception;

public class TraineeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2429005644596060387L;
	
	public TraineeException(){
		super();
	}
	public TraineeException(String message){
		super(message);
	}
}
