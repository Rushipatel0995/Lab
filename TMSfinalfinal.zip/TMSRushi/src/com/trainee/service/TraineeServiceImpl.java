package com.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainee.bean.TraineeBean;
import com.trainee.dao.ITraineeDao;
import com.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	private ITraineeDao traineeDao;
	
	@Override
	public void addTrainee(TraineeBean bean) throws TraineeException {
	traineeDao.addTrainee(bean);
	}

	@Override
	public List<TraineeBean> viewAll() throws TraineeException {
		
		return traineeDao.viewAll();
	}

	@Override
	public TraineeBean view(int id) throws TraineeException {
		
		return traineeDao.view(id);
	}

	@Override
	public TraineeBean delete(int id) throws TraineeException {
		
		return traineeDao.delete(id);
	}

	@Override
	public boolean update(TraineeBean bean) throws TraineeException {
		
		return traineeDao.update(bean);
	}

}
