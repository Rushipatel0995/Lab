package com.trainee.service;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeService {
	public void addTrainee(TraineeBean bean) throws TraineeException;
	
	public List<TraineeBean> viewAll() throws TraineeException;
	
	public TraineeBean view(int id) throws TraineeException;
	
	public TraineeBean delete(int id) throws TraineeException;
	
	public boolean update(TraineeBean bean) throws TraineeException;
}
