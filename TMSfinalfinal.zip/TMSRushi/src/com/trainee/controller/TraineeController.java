package com.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("showHomePage")
	public String showHomePage(){
		return "index";
	}
	
	@RequestMapping("add")
	public String showAdd(){
		return "add";
	}
	
	@RequestMapping(value="addTrainee",method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") TraineeBean bean,BindingResult result){
		ModelAndView model = new ModelAndView();
		
		if(result.hasErrors()){
			
			model.setViewName("error");
			model.addObject("message","Unable to bind");
		}
		else{
			try {
				traineeService.addTrainee(bean);
				model.setViewName("success");
				model.addObject("trainee",bean);
			} catch (TraineeException e) {
				model.setViewName("error");
				model.addObject("message","Unable to add trainee in controller"+e.getMessage());
			}
		}
		return model;
		
	}
	
	@RequestMapping("view")
	public ModelAndView viewAll(@ModelAttribute("trainee") TraineeBean bean,BindingResult result){
ModelAndView model=new ModelAndView();
		
		
		try {
			List<TraineeBean> list=traineeService.viewAll();
			
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());
		}
		
		
		return model;
	}
	
	@RequestMapping("viewone")
	public String viewOne(){
		return "successView";
	}
	
	@RequestMapping(value="retrieve",method=RequestMethod.POST)
	public ModelAndView retrieve(@RequestParam("traineeId") int traineeId){
		
		ModelAndView model = new ModelAndView();
		TraineeBean bean1=new TraineeBean();
		
		try {
			bean1=traineeService.view(traineeId);
			model.addObject("trainee",bean1);
			model.addObject("message", "Deleted");
			
			model.setViewName("successView");
			
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message","Unable to view in controller"+e.getMessage());
		}
		
		return model;
		
	}
	
	@RequestMapping("delete")
	public String deletePage(){
		return "delete";
	}
	
	@RequestMapping(value="getDetail",method=RequestMethod.POST)
	public ModelAndView getDetail(@RequestParam("traineeId") int traineeId) throws TraineeException{
		ModelAndView model = new ModelAndView();
		try {
			TraineeBean trainee=traineeService.view(traineeId);
			model.addObject("trainee", trainee);
			model.addObject("message", "Deleted");
			model.setViewName("delete");
		} catch (Exception e) {
			model.setViewName("error");
			model.addObject("message","Unable to delete in controller"+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping(value="getDetailUpdate",method=RequestMethod.POST)
	public ModelAndView getDetailUpdate(@RequestParam("traineeId") int traineeId) throws TraineeException{
		ModelAndView model = new ModelAndView();
		try {
			TraineeBean trainee=traineeService.view(traineeId);
			model.addObject("trainee", trainee);
			model.addObject("message", "Deleted");
			model.setViewName("update");
		} catch (Exception e) {
			model.setViewName("error");
			model.addObject("message","Unable to delete in controller"+e.getMessage());
		}
		return model;
	}
	@RequestMapping(value="deleteTrainee",method=RequestMethod.POST)
	public ModelAndView delete(@RequestParam("traineeId") int traineeId){
		
		ModelAndView model = new ModelAndView();
		TraineeBean bean= new TraineeBean();
		
		 try {
			bean=traineeService.delete(traineeId);
			 model.setViewName("deleteSuccess");
			 model.addObject("trainee",bean);
			 
			 model.addObject("message","Record not found");
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message","Unable to delete in controller"+e.getMessage());
			
		}
		 return model;
	}
	
	@RequestMapping("update")
	public String updatePage(){
		
		return "update";
		
	}
	
	@RequestMapping("updatesuccess")
	public ModelAndView update(@ModelAttribute("trainee") TraineeBean bean){
		
		ModelAndView model=new ModelAndView();
		
		
		try {
			boolean isUpdated=traineeService.update(bean);
			model.setViewName("updatesuccess");
			model.addObject("trainee", isUpdated);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message","unable to update in dao layer"+e.getMessage());
		}
		return model;
		
	}
	
	
}
