package com.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;


@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public void addTrainee(TraineeBean bean) throws TraineeException {
		
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			
		} catch (Exception e) {
			throw new TraineeException("Unable to persist in dao layer"+e.getMessage());
			
		}
		
		
	}
	@Override
	public List<TraineeBean> viewAll() throws TraineeException {
		List<TraineeBean> list=null;
		try {
			TypedQuery<TraineeBean> qry = entityManager.createQuery("from TraineeBean",TraineeBean.class);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new TraineeException("unable to fetch data in dao layer!"+e.getMessage());
		}
		
		return list;
	}
	@Override
	public TraineeBean view(int id) throws TraineeException {
		TraineeBean bean=new TraineeBean();
		
		try {
			TypedQuery<TraineeBean> qry= entityManager.createQuery("from TraineeBean where traineeId=:id",TraineeBean.class);
			qry.setParameter("id", id);
			bean=qry.getSingleResult();
			
		} catch (Exception e) {
			throw new TraineeException("\n\n\n\nUnable to view in dao layer\n\n\n\n"+e.getMessage());
		}
		return bean;
	}
	@Override
	public TraineeBean delete(int id) throws TraineeException {

		TraineeBean trainee=new TraineeBean();
		try {
			trainee=entityManager.find(TraineeBean.class,id);
			


				entityManager.remove(trainee);
				
		} catch (Exception e) {
			throw new TraineeException("Unable to delete in dao layer!"+e.getMessage());
			
		}
			
		
		
		return trainee;
	}
	@Override
	public boolean update(TraineeBean bean) throws TraineeException {
boolean isUpdated=false;
		
		
		try {
		//	EmployeeBean emp=entityManager.find(EmployeeBean.class, bean.getEmployeeId());

			
				//emp.setEmployeeName("Shyam");
				
				entityManager.merge(bean);
				isUpdated=true;
		} catch (Exception e) {
			throw new TraineeException("Unable to update employee in dao layer"+e.getMessage());
		}
		
		return isUpdated;
	}
	}


