package com.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("showHomePage")
	public String showHomePage(){
		return "index";
	}
	
	@RequestMapping("add")
	public String showAdd(){
		return "add";
	}
	
	@RequestMapping(value="addTrainee",method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") TraineeBean bean,BindingResult result){
		ModelAndView model = new ModelAndView();
		
		if(result.hasErrors()){
			
			model.setViewName("error");
			model.addObject("message","Unable to bind");
		}
		else{
			try {
				traineeService.addTrainee(bean);
				model.setViewName("success");
				model.addObject("trainee",bean);
			} catch (TraineeException e) {
				model.setViewName("error");
				model.addObject("message","Unable to add trainee in controller"+e.getMessage());
			}
		}
		return model;
		
	}
	
	@RequestMapping("view")
	public ModelAndView viewAll(@ModelAttribute("trainee") TraineeBean bean,BindingResult result){
ModelAndView model=new ModelAndView();
		
		
		try {
			List<TraineeBean> list=traineeService.viewAll();
			
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());
		}
		
		
		return model;
	}
	
	@RequestMapping("viewone")
	public String viewOne(){
		return "viewone";
	}
	
	@RequestMapping(value="retrieve",method=RequestMethod.POST)
	public ModelAndView retrieve(@ModelAttribute("trainee") TraineeBean bean,BindingResult result){
		
		ModelAndView model = new ModelAndView();
		TraineeBean bean1=new TraineeBean();
		if(result.hasErrors()){
			model.setViewName("error");
			model.addObject("message","Unable to view in controller");
		}
		try {
			bean1=traineeService.view(bean.getTraineeId());
			
			model.setViewName("successView");
			model.addObject("trainee",bean1);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("message","Unable to view in controller"+e.getMessage());
		}
		
		return model;
		
	}
	
	
}
