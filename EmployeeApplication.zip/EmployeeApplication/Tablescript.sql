CREATE TABLE Employee_table
(
Employee_Id NUMBER PRIMARY KEY,
Employee_Name VARCHAR2(20),
Phone_Number VARCHAR2(20),
Address VARCHAR2(20),
Salary NUMBER,
Joining_Date DATE
);


CREATE SEQUENCE employeeId_Sequence
START WITH 1000;
