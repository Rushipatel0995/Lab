package com.employee.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;
import com.employee.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("*obj")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeServiceImpl employeeService = null;
		EmployeeBean employeeBean = null;
		String target = "";

		HttpSession session = request.getSession(true);
		// Object creations
		employeeBean = new EmployeeBean();
		employeeService = new EmployeeServiceImpl();
		int employeeId = 0;
		String targetAdd = "/addEmployee.jsp";
		String targetSuccess = "/success.jsp";
		String targetView = "/viewEmployee.jsp";
		String targetViewAll = "/viewAllEmployees.jsp";
		String targetError = "/error.jsp";
		String targetHome = "/index.jsp";

		String path = request.getServletPath().trim();
		
		switch (path) {
		case "view/Home.obj":
			session.setAttribute("error", null);
			session.setAttribute("employee", null);
			target = targetHome;
			
			break;
		case "view/Add Employee.obj":
			target = targetAdd;
			break;
		case "view/Added.obj":
			List<String> errorList = new ArrayList<String>();

			String employeeName = request.getParameter("employeeName").trim();
			long phoneNumber = Long.parseLong(request.getParameter(
					"phoneNumber").trim());
			String address = request.getParameter("address").trim();
			int salary = Integer.parseInt(request.getParameter("salary")
					.trim());

			employeeBean.setEmployeeName(employeeName);
			employeeBean.setAddress(address);
			employeeBean.setPhoneNumber(phoneNumber);
			employeeBean.setSalary(salary);

			employeeBean.setJoiningDate(LocalDate.now());
			errorList = employeeService.isValidated(employeeBean);

			if (errorList.isEmpty()) {
				/************ Code for Adding donation Details **************/
				try {
					employeeId = employeeService.insertEmployee(employeeBean);
				} catch (EmployeeException e) {
					session.setAttribute("error", e.getMessage());
					target = targetError;
				}
				if (employeeId != 0) {
					employeeBean.setEmployeeId(employeeId);

					// set ID to display ID alone
					// session.setAttribute("donorId", donorId);
					session.setAttribute("employee", employeeBean);
					target = targetSuccess;
				}

			} else {
				session.setAttribute("errorList", errorList);
				target = targetAdd;
			}

			break;
			// Redirect to View Donation Page
		case "view/View Employee.obj":
			target = targetView;
			break;
			// Code for Searching a particular donor history
		case "view/Search.obj":
			employeeId = Integer.parseInt(request.getParameter("employeeId"));
			try {
				employeeBean = employeeService.viewEmployee(employeeId);
			} catch (EmployeeException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (employeeBean.getEmployeeId() != 0) {
				session.setAttribute("error", null);
				session.setAttribute("employee", employeeBean);
				target = targetView;
			} else {
				session.setAttribute("employee", null);
				session.setAttribute("error",
						"Sorry No data Found for given ID!");
				target = targetError;
			}

			break;
		case "view/View All Employees.obj":
			List<EmployeeBean> donorList = null;
			try {
				donorList = employeeService.viewAllEmployee();
			} catch (EmployeeException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (!donorList.isEmpty()) {
				session.setAttribute("error", null);
				session.setAttribute("employeeList", donorList);
				target = targetViewAll;
			} else {
				session.setAttribute("employeeList", null);
				session.setAttribute("error", "Sorry No data Found!");
				target = targetViewAll;
			}

			break;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
