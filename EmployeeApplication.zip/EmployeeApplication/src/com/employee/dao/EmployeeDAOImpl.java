package com.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;
import com.employee.util.DbConnection;

public class EmployeeDAOImpl implements IEmployeeDAO {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	@Override
	public int insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		int result = 0;
		int sequence = 0;
		try {
			conn = DbConnection.getConnection();
			
			preparedStatement = conn
					.prepareStatement(QuerryMapper.GET_ID);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				sequence = resultSet.getInt(1);
			} else {
				sequence = 0;
			}
			if (sequence != 0) {

				preparedStatement = conn
						.prepareStatement(QuerryMapper.INSERT_EMPLOYEE);
				preparedStatement.setInt(1, sequence);
				preparedStatement.setString(2, employeeBean.getEmployeeName());
				preparedStatement.setLong(3, employeeBean.getPhoneNumber());
				preparedStatement.setString(4, employeeBean.getAddress());
				preparedStatement.setInt(5, employeeBean.getSalary());
				preparedStatement.setDate(6,
						java.sql.Date.valueOf(employeeBean.getJoiningDate()));
				result = preparedStatement.executeUpdate();

				if (result == 0) {
					return 0;
				}
			}

		} catch (SQLException e) {
			throw new EmployeeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new EmployeeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new EmployeeException(
						"Could not close the connection");
			}
		}
		return sequence;
		
	}

	@Override
	public EmployeeBean viewEmployee(int employeeId) throws EmployeeException {
		
		EmployeeBean employeeBean = new EmployeeBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QuerryMapper.VIEW);
			preparedStatement.setInt(1, employeeId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				employeeBean.setEmployeeId(resultSet.getInt(1));;
				employeeBean.setEmployeeName(resultSet.getString(2));;
				employeeBean.setPhoneNumber(resultSet.getLong(3));
				employeeBean.setAddress(resultSet.getString(4));
				employeeBean.setSalary(resultSet.getInt(5));;
				// Convert SQL to Calendar Date
				// Date date = resultSet.getDate(6);
				/*
				 * Calendar cDate = Calendar.getInstance(); cDate.setTime(date);
				 */
				employeeBean.setJoiningDate(resultSet.getDate(6).toLocalDate());;
			}

		} catch (SQLException e) {
			throw new EmployeeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new EmployeeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new EmployeeException(
						"Could not close the connection");
			}
		}
		return employeeBean;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		
		List<EmployeeBean> list = new ArrayList<EmployeeBean>();
		EmployeeBean employeeBean = new EmployeeBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QuerryMapper.VIEW_ALL);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				employeeBean.setEmployeeId(resultSet.getInt(1));
				employeeBean.setEmployeeName(resultSet.getString(2));;
				employeeBean.setPhoneNumber(resultSet.getLong(3));;
				employeeBean.setAddress(resultSet.getString(4));
				employeeBean.setSalary(resultSet.getInt(5));;
				employeeBean.setJoiningDate(resultSet.getDate(6).toLocalDate());;
				list.add(employeeBean);
				employeeBean = new EmployeeBean();
			}
		} catch (SQLException e) {
			throw new EmployeeException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new EmployeeException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new EmployeeException(
						"Could not close the connection");
			}
		}
		return list;

	}

}
