package com.employee.dao;

import java.util.List;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public interface IEmployeeDAO {
	
	public int insertEmployee(EmployeeBean employeeBean) throws EmployeeException;
	
	public EmployeeBean viewEmployee(int employeeId) throws EmployeeException;
	
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException;
}
