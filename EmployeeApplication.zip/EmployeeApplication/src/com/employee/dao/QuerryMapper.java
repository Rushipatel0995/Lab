package com.employee.dao;

public interface QuerryMapper {
	
	String GET_ID="SELECT employeeId_Sequence.NEXTVAL FROM dual";
	
	String INSERT_EMPLOYEE="INSERT INTO Employee_table VALUES(?,?,?,?,?,?)";
	
	String VIEW_ALL="SELECT * FROM Employee_table";
	
	String VIEW="SELECT * from Employee_table WHERE Employee_Id=?";
	
}
