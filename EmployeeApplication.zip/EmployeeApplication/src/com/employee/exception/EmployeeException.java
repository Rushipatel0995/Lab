package com.employee.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8630829671543514772L;
	
	public EmployeeException(){
		super();
	}
	public EmployeeException(String message){
		super(message);
	}

}
