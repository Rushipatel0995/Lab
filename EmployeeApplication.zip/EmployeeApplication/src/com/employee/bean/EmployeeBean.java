package com.employee.bean;

import java.time.LocalDate;

public class EmployeeBean {
	private int employeeId;
	private String employeeName;
	private long phoneNumber;
	private String address;
	private int salary;
	private LocalDate joiningDate;
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(int employeeId, String employeeName, long phoneNumber,
			String address, int salary, LocalDate joiningDate) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.salary = salary;
		this.joiningDate = joiningDate;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	@Override
	public String toString() {
		return "EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", phoneNumber=" + phoneNumber + ", address="
				+ address + ", salary=" + salary + ", joiningDate="
				+ joiningDate + "]";
	}
	
	
}
