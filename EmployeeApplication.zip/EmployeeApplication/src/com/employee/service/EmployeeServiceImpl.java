package com.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.employee.bean.EmployeeBean;
import com.employee.dao.EmployeeDAOImpl;
import com.employee.dao.IEmployeeDAO;
import com.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployeeDAO employee = new EmployeeDAOImpl();
	@Override
	public int insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		
		int result = employee.insertEmployee(employeeBean);
		return result;
	}

	@Override
	public EmployeeBean viewEmployee(int employeeId) throws EmployeeException {
		EmployeeBean employee1 = new EmployeeBean();

		employee1 = employee.viewEmployee(employeeId);
		return employee1;
		
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {

		List<EmployeeBean> list = employee.viewAllEmployee();
		return list;
	}



public List<String> isValidated(EmployeeBean employee) {
	List<String> errorList = new ArrayList<String>();

	Pattern pattern = null;
	Matcher matcher = null;

	// Donor Name Validation
	pattern = Pattern.compile("^[A-Za-z\\s]{3,25}$");
	matcher = pattern.matcher(employee.getEmployeeName());
	if (!matcher.matches()) {
		errorList.add("Please enter a valid Name");
	}

	// Phone Number Validation
	if (employee.getPhoneNumber() <= 999999999) {
		errorList.add("Please enter a valid Phone Number");
	}

	// Address Validation
	pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
	matcher = pattern.matcher(employee.getAddress());
	if (!matcher.matches()) {
		errorList.add("Please enter a valid Address");
	}

	// Amount Validation
	if (employee.getSalary() <= 0) {
		errorList.add("Please enter a valid Amount");
	}
	return errorList;
}

}

